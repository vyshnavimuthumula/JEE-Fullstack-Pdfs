package com.capgemini.lesson2;

class AccountBalance {
	public static void main(String args[]) {

		Balance current = new Balance("K. J. Fielding", 123.23);
		current.show();

	}
}
